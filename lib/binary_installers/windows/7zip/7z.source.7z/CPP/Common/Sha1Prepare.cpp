// Sha1Prepare.cpp

#include "StdAfx.h"

#include "../../C/Sha1.h"

static struct CSha1Prepare { CSha1Prepare() { Sha1Prepare(); } } g_Sha1Prepare;
